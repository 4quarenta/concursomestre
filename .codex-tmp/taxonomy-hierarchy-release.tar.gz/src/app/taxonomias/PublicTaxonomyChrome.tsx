import Link from 'next/link';
import BrandLogo from '@/components/shared/layout/BrandLogo';
import Footer from '@/components/shared/layout/Footer';

export const PublicTaxonomyHeader = () => (
  <header className="border-b border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-950">
    <div className="relative mx-auto flex max-w-7xl items-center px-5 py-4 min-[360px]:pr-28 md:pr-64 lg:px-8 lg:pr-72">
      <Link href="/" prefetch={false} className="inline-flex items-center transition-opacity hover:opacity-90" aria-label="Ir para a página inicial do ConcursoMestre">
        <BrandLogo width={180} priority variant="adaptive" alt="ConcursoMestre" />
      </Link>
      <nav className="absolute right-5 top-1/2 flex -translate-y-1/2 items-center gap-2 text-sm font-bold lg:right-8" aria-label="Navegação pública">
        <Link href="/practice" prefetch={false} className="px-3 py-2 hover:text-indigo-600">Questões</Link>
        <Link href="/disciplinas" prefetch={false} className="hidden px-3 py-2 hover:text-indigo-600 sm:inline-flex">Disciplinas</Link>
        <Link href="/bancas" prefetch={false} className="hidden px-3 py-2 hover:text-indigo-600 sm:inline-flex">Bancas</Link>
        <Link href="/blog" prefetch={false} className="hidden px-3 py-2 hover:text-indigo-600 md:inline-flex">Blog</Link>
        <Link href="/auth" prefetch={false} className="rounded-md bg-slate-950 px-4 py-2 text-white hover:bg-indigo-700 dark:bg-white dark:text-slate-950">Entrar</Link>
      </nav>
    </div>
  </header>
);

export const PublicTaxonomyFooter = () => (
  <div className="mx-auto w-full max-w-7xl px-5 lg:px-8"><Footer /></div>
);
