import { resolveAbsoluteApiBaseUrl } from '@services/api/baseUrl';

export type PublicTaxonomyDirectoryKind = 'subjects' | 'boards';

export type PublicTaxonomyDirectoryItem = {
  id: number;
  name: string;
  slug: string;
  acronym: string | null;
  description: string | null;
  imageUrl: string | null;
  questionCount: number;
  examCount: number;
};

export type PublicTaxonomyDirectoryPage = {
  items: PublicTaxonomyDirectoryItem[];
  pageInfo: {
    page: number;
    perPage: number;
    pages: number;
    total: number;
    hasPrevious: boolean;
    hasMore: boolean;
  };
};

const EMPTY_PAGE: PublicTaxonomyDirectoryPage = {
  items: [],
  pageInfo: {
    page: 1,
    perPage: 30,
    pages: 1,
    total: 0,
    hasPrevious: false,
    hasMore: false,
  },
};

const readEnvelopeData = (payload: unknown): unknown => {
  if (!payload || typeof payload !== 'object') return null;
  return Object.prototype.hasOwnProperty.call(payload, 'data')
    ? (payload as { data?: unknown }).data
    : payload;
};

export const fetchPublicTaxonomyDirectory = async ({
  type,
  page,
  search,
  letter,
}: {
  type: PublicTaxonomyDirectoryKind;
  page: number;
  search: string;
  letter: string;
}): Promise<PublicTaxonomyDirectoryPage> => {
  const apiBaseUrl = resolveAbsoluteApiBaseUrl(
    process.env.NEXT_PUBLIC_API_BASE_URL || process.env.API_BASE_URL || undefined,
  );
  const url = new URL('filters/directory.php', apiBaseUrl);
  url.searchParams.set('type', type);
  url.searchParams.set('page', String(Math.max(1, page)));
  url.searchParams.set('per_page', '30');
  if (search) url.searchParams.set('search', search);
  if (letter) url.searchParams.set('letter', letter);

  try {
    const response = await fetch(url.toString(), {
      headers: { Accept: 'application/json' },
      next: { revalidate: 300 },
    });
    if (!response.ok) return EMPTY_PAGE;

    const data = readEnvelopeData(await response.json());
    if (!data || typeof data !== 'object') return EMPTY_PAGE;
    const record = data as Partial<PublicTaxonomyDirectoryPage>;
    const pageInfo = record.pageInfo || EMPTY_PAGE.pageInfo;

    return {
      items: Array.isArray(record.items) ? record.items.map((item) => ({
        id: Number(item.id || 0),
        name: String(item.name || '').trim(),
        slug: String(item.slug || '').trim(),
        acronym: item.acronym ? String(item.acronym).trim() : null,
        description: item.description ? String(item.description).trim() : null,
        imageUrl: item.imageUrl ? String(item.imageUrl).trim() : null,
        questionCount: Math.max(0, Number(item.questionCount || 0)),
        examCount: Math.max(0, Number(item.examCount || 0)),
      })).filter((item) => item.id > 0 && item.name !== '') : [],
      pageInfo: {
        page: Math.max(1, Number(pageInfo.page || 1)),
        perPage: Math.max(1, Number(pageInfo.perPage || 30)),
        pages: Math.max(1, Number(pageInfo.pages || 1)),
        total: Math.max(0, Number(pageInfo.total || 0)),
        hasPrevious: Boolean(pageInfo.hasPrevious),
        hasMore: Boolean(pageInfo.hasMore),
      },
    };
  } catch {
    return EMPTY_PAGE;
  }
};
