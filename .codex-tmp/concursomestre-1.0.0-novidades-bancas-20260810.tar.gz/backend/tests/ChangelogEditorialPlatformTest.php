<?php

declare(strict_types=1);

require_once __DIR__ . '/../modules/changelog/validators/ChangelogValidator.php';

function assertChangelogEditorial(bool $condition, string $message): void
{
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

$backend = dirname(__DIR__);
$root = dirname($backend);
$validator = new ChangelogValidator();
$entry = $validator->validateSave([
    'title' => 'Agora ficou mais facil revisar questoes',
    'description' => 'Os filtros foram reorganizados para encontrar conteudo com menos passos.',
    'releaseDate' => '2026-08-10',
    'status' => 'published',
    'content' => [[
        'title' => 'O que mudou',
        'icon' => 'Sparkles',
        'items' => ['Filtros mais claros.', 'Navegacao mais rapida.'],
    ]],
]);
assertChangelogEditorial($entry['slug'] === 'agora-ficou-mais-facil-revisar-questoes', 'The slug must be canonical.');
assertChangelogEditorial(count($entry['content']) === 1, 'At least one user-facing section must be preserved.');

$suggestion = $validator->validateSuggestionUpdate(['id' => 7, 'status' => 'completed']);
assertChangelogEditorial($suggestion['status'] === 'completed', 'Completed must be a valid product status.');
try {
    $validator->validateSuggestionUpdate(['id' => 7, 'status' => 'resolved']);
    throw new RuntimeException('Support status must not be accepted as product status.');
} catch (InvalidArgumentException) {
}

$migration = (string) file_get_contents($backend . '/database/migrations/20260810_230000_novidades_editorial.php');
foreach (['CREATE TABLE IF NOT EXISTS changelogs', 'suggestion_status', 'idx_feedback_suggestion_workflow'] as $needle) {
    assertChangelogEditorial(str_contains($migration, $needle), 'Migration is missing ' . $needle . '.');
}

$routes = (string) file_get_contents($backend . '/modules/changelog/routes.php');
foreach (['requireAdminSessionContext', 'handleChangelogAdminSaveRoute', 'handleChangelogAdminSuggestionsRoute', 'logAdminAudit'] as $needle) {
    assertChangelogEditorial(str_contains($routes, $needle), 'Admin changelog routes are missing ' . $needle . '.');
}

$repository = (string) file_get_contents($backend . '/modules/changelog/repositories/ChangelogRepository.php');
assertChangelogEditorial(str_contains($repository, "status = 'published'"), 'The public query must serialize only published entries.');
assertChangelogEditorial(str_contains($repository, "f.type = 'suggestion'"), 'The suggestion queue must only include suggestions.');
assertChangelogEditorial(str_contains($repository, 'LIMIT :limit OFFSET :offset'), 'Admin queues must be paginated.');

$publicPage = (string) file_get_contents($root . '/src/app/novidades/page.tsx');
foreach (['Novidades', 'CollectionPage', 'fetchChangelogForServer', 'entry.content.map'] as $needle) {
    assertChangelogEditorial(str_contains($publicPage, $needle), 'SSR novidades page is missing ' . $needle . '.');
}

$adminPage = (string) file_get_contents($root . '/src/app/admin/components/changelog/AdminChangelogSection.tsx');
foreach (['Arquivo de novidades', 'Sugestões dos usuários', 'AdminCollectionPagination', 'PRODUCT_STATUS_OPTIONS'] as $needle) {
    assertChangelogEditorial(str_contains($adminPage, $needle), 'Admin novidades library is missing ' . $needle . '.');
}

fwrite(STDOUT, "Changelog editorial platform assertions passed.\n");
