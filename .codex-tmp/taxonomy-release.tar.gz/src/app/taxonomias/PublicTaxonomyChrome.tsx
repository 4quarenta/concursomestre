import Link from 'next/link';
import PublicBrandLink from '@/components/shared/layout/PublicBrandLink';

export const PublicTaxonomyHeader = () => (
  <header className="border-b border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-950">
    <div className="mx-auto flex min-h-20 max-w-7xl items-center justify-between gap-6 px-5 py-4 lg:px-8">
      <PublicBrandLink width={190} priority surface="theme" />
      <nav className="flex flex-wrap items-center justify-end gap-x-2 gap-y-1 text-sm font-bold text-slate-700 dark:text-slate-200" aria-label="Navegação pública">
        <Link href="/practice" prefetch={false} className="px-3 py-2 hover:text-indigo-600">Questões</Link>
        <Link href="/disciplinas" prefetch={false} className="hidden px-3 py-2 hover:text-indigo-600 sm:inline-flex">Disciplinas</Link>
        <Link href="/bancas" prefetch={false} className="hidden px-3 py-2 hover:text-indigo-600 sm:inline-flex">Bancas</Link>
        <Link href="/blog" prefetch={false} className="hidden px-3 py-2 hover:text-indigo-600 md:inline-flex">Blog</Link>
        <Link href="/auth" prefetch={false} className="rounded-md bg-slate-950 px-4 py-2 text-white hover:bg-indigo-700 dark:bg-white dark:text-slate-950">Entrar</Link>
      </nav>
    </div>
  </header>
);

export const PublicTaxonomyFooter = () => (
  <footer className="border-t border-slate-200 bg-slate-950 text-slate-200">
    <div className="mx-auto grid max-w-7xl gap-10 px-5 py-12 sm:grid-cols-2 lg:grid-cols-4 lg:px-8">
      <div>
        <PublicBrandLink width={190} surface="dark" />
        <p className="mt-4 max-w-xs text-sm leading-6 text-slate-400">Estude por disciplina, banca e questões anteriores com filtros objetivos.</p>
      </div>
      <div>
        <h2 className="text-sm font-black text-white">Estudar</h2>
        <div className="mt-4 flex flex-col gap-3 text-sm text-slate-400">
          <Link href="/practice" prefetch={false} className="hover:text-white">Questões</Link>
          <Link href="/disciplinas" prefetch={false} className="hover:text-white">Disciplinas</Link>
          <Link href="/bancas" prefetch={false} className="hover:text-white">Bancas</Link>
          <Link href="/lei-comentada" prefetch={false} className="hover:text-white">Lei comentada</Link>
        </div>
      </div>
      <div>
        <h2 className="text-sm font-black text-white">Conteúdo</h2>
        <div className="mt-4 flex flex-col gap-3 text-sm text-slate-400">
          <Link href="/blog" prefetch={false} className="hover:text-white">Blog</Link>
          <Link href="/concursos" prefetch={false} className="hover:text-white">Concursos</Link>
          <Link href="/faq" prefetch={false} className="hover:text-white">FAQ</Link>
        </div>
      </div>
      <div>
        <h2 className="text-sm font-black text-white">Legal</h2>
        <div className="mt-4 flex flex-col gap-3 text-sm text-slate-400">
          <Link href="/terms" prefetch={false} className="hover:text-white">Termos de uso</Link>
          <Link href="/privacy" prefetch={false} className="hover:text-white">Privacidade</Link>
          <Link href="/support" prefetch={false} className="hover:text-white">Suporte</Link>
        </div>
      </div>
    </div>
  </footer>
);
