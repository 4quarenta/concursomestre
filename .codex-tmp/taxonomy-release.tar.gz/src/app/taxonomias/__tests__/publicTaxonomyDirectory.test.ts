import fs from 'node:fs';
import path from 'node:path';
import { describe, expect, it } from 'vitest';

const readSource = (relativePath: string) => fs.readFileSync(path.resolve(process.cwd(), relativePath), 'utf8');
const directorySource = readSource('src/app/taxonomias/PublicTaxonomyDirectory.tsx');
const serverDataSource = readSource('src/app/taxonomias/taxonomyDirectoryServerData.ts');
const frameSource = readSource('src/providers/NextRouteFrame.tsx');
const landingSource = readSource('src/app/landing/components/LandingCommercialPage.tsx');
const footerSource = readSource('src/components/shared/layout/Footer.tsx');

describe('public taxonomy directories', () => {
  it('renders disciplines and boards on the server with search, alphabet and pagination', () => {
    expect(readSource('src/app/disciplinas/page.tsx')).toContain('type="subjects"');
    expect(readSource('src/app/bancas/page.tsx')).toContain('type="boards"');
    expect(directorySource).toContain('LETTERS.map');
    expect(directorySource).toContain('name="busca"');
    expect(directorySource).toContain('directory.pageInfo.hasMore');
    expect(serverDataSource).toContain("next: { revalidate: 300 }");
    expect(serverDataSource).toContain("filters/directory.php");
  });

  it('keeps the directories outside the authenticated sidebar and links them publicly', () => {
    expect(frameSource).toContain("'/disciplinas'");
    expect(frameSource).toContain("'/bancas'");
    expect(landingSource).toContain("{ label: 'Disciplinas', href: '/disciplinas' }");
    expect(landingSource).toContain("{ label: 'Bancas', href: '/bancas' }");
    expect(footerSource).toContain("path: '/disciplinas'");
    expect(footerSource).toContain("path: '/bancas'");
  });

  it('does not use the broad administrative taxonomy contract', () => {
    expect(serverDataSource).not.toContain('filtersList');
    expect(serverDataSource).not.toContain('adminFiltersList');
  });
});
