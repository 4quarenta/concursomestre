import Link from 'next/link';
import { Search } from 'lucide-react';
import { buildSiteUrl } from '@/config/siteUrl';
import { serializeStructuredData } from '@services/seo/structuredData';
import { PublicTaxonomyFooter, PublicTaxonomyHeader } from './PublicTaxonomyChrome';
import { fetchPublicTaxonomyDirectory, type PublicTaxonomyDirectoryKind } from './taxonomyDirectoryServerData';

const LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

type DirectoryConfig = {
  path: '/disciplinas' | '/bancas';
  title: string;
  singular: string;
  description: string;
  searchPlaceholder: string;
  practiceQueryKey: 'materia' | 'banca';
};

const CONFIG: Record<PublicTaxonomyDirectoryKind, DirectoryConfig> = {
  subjects: {
    path: '/disciplinas',
    title: 'Disciplinas',
    singular: 'disciplina',
    description: 'Explore as disciplinas com questões publicadas e direcione seus estudos por conteúdo.',
    searchPlaceholder: 'Digite o nome da disciplina',
    practiceQueryKey: 'materia',
  },
  boards: {
    path: '/bancas',
    title: 'Bancas',
    singular: 'banca',
    description: 'Conheça as bancas disponíveis e pratique com questões organizadas por perfil de cobrança.',
    searchPlaceholder: 'Digite o nome ou a sigla da banca',
    practiceQueryKey: 'banca',
  },
};

const buildDirectoryHref = (
  path: DirectoryConfig['path'],
  params: { page?: number; search?: string; letter?: string },
) => {
  const query = new URLSearchParams();
  if (params.search) query.set('busca', params.search);
  if (params.letter) query.set('letra', params.letter);
  if (params.page && params.page > 1) query.set('pagina', String(params.page));
  const serialized = query.toString();
  return serialized ? `${path}?${serialized}` : path;
};

export default async function PublicTaxonomyDirectory({
  type,
  searchParams,
}: {
  type: PublicTaxonomyDirectoryKind;
  searchParams: Promise<{ busca?: string; letra?: string; pagina?: string }>;
}) {
  const config = CONFIG[type];
  const params = await searchParams;
  const search = String(params.busca || '').trim().slice(0, 100);
  const letterCandidate = String(params.letra || '').trim().toUpperCase();
  const letter = /^[A-Z]$/.test(letterCandidate) ? letterCandidate : '';
  const requestedPage = Math.max(1, Number.parseInt(String(params.pagina || '1'), 10) || 1);
  const directory = await fetchPublicTaxonomyDirectory({ type, page: requestedPage, search, letter });
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'CollectionPage',
    name: config.title,
    description: config.description,
    url: buildSiteUrl(config.path),
    mainEntity: {
      '@type': 'ItemList',
      numberOfItems: directory.items.length,
      itemListElement: directory.items.map((item, index) => ({
        '@type': 'ListItem',
        position: ((directory.pageInfo.page - 1) * directory.pageInfo.perPage) + index + 1,
        name: item.name,
        url: buildSiteUrl(`/practice?${config.practiceQueryKey}=${encodeURIComponent(item.name)}`),
      })),
    },
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-950 dark:bg-slate-900 dark:text-white">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: serializeStructuredData(jsonLd) }} />
      <PublicTaxonomyHeader />
      <main className="mx-auto w-full max-w-7xl px-5 py-10 lg:px-8 lg:py-14">
        <nav className="flex items-center gap-3 text-sm font-medium text-slate-500" aria-label="Breadcrumb">
          <Link href="/" className="hover:text-indigo-600">Início</Link>
          <span aria-hidden="true">/</span>
          <span className="text-slate-800 dark:text-slate-200">{config.title}</span>
        </nav>

        <header className="mt-5">
          <h1 className="text-3xl font-black tracking-tight sm:text-4xl">{config.title}</h1>
          <p className="mt-3 max-w-3xl text-base leading-7 text-slate-600 dark:text-slate-300">{config.description}</p>
        </header>

        <section className="mt-10 space-y-5" aria-label={`Filtros de ${config.title.toLowerCase()}`}>
          <div className="overflow-x-auto pb-1">
            <div className="flex min-w-max overflow-hidden rounded-md border border-slate-300 bg-white dark:border-slate-700 dark:bg-slate-950">
              {LETTERS.map((value) => (
                <Link
                  key={value}
                  href={buildDirectoryHref(config.path, { search, letter: value })}
                  prefetch={false}
                  aria-current={letter === value ? 'page' : undefined}
                  className={`flex h-11 w-12 items-center justify-center border-r border-slate-200 text-sm font-bold transition-colors last:border-r-0 dark:border-slate-800 ${letter === value ? 'bg-indigo-700 text-white' : 'text-slate-600 hover:bg-slate-100 hover:text-indigo-700 dark:text-slate-300 dark:hover:bg-slate-800'}`}
                >
                  {value}
                </Link>
              ))}
              <Link
                href={buildDirectoryHref(config.path, { search })}
                prefetch={false}
                aria-current={!letter ? 'page' : undefined}
                className={`flex h-11 min-w-20 items-center justify-center px-4 text-sm font-bold transition-colors ${!letter ? 'bg-indigo-700 text-white' : 'text-slate-600 hover:bg-slate-100 hover:text-indigo-700 dark:text-slate-300 dark:hover:bg-slate-800'}`}
              >
                Todos
              </Link>
            </div>
          </div>

          <form action={config.path} method="get" className="flex flex-col gap-3 sm:flex-row">
            {letter ? <input type="hidden" name="letra" value={letter} /> : null}
            <label className="relative flex-1">
              <span className="sr-only">{config.searchPlaceholder}</span>
              <Search size={19} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                name="busca"
                defaultValue={search}
                placeholder={config.searchPlaceholder}
                className="h-14 w-full rounded-md border border-slate-300 bg-white pl-12 pr-4 text-sm font-medium outline-none transition focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/15 dark:border-slate-700 dark:bg-slate-950"
              />
            </label>
            <button type="submit" className="h-14 rounded-md bg-indigo-700 px-7 text-sm font-bold text-white hover:bg-indigo-800">Filtrar</button>
            {(search || letter) ? (
              <Link href={config.path} prefetch={false} className="flex h-14 items-center justify-center rounded-md border border-slate-300 bg-white px-7 text-sm font-bold text-slate-700 hover:border-indigo-400 hover:text-indigo-700 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200">Limpar</Link>
            ) : null}
          </form>
        </section>

        <section className="mt-10" aria-live="polite">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-lg font-black">{directory.pageInfo.total.toLocaleString('pt-BR')} {directory.pageInfo.total === 1 ? config.singular : config.title.toLowerCase()}</h2>
            <span className="text-xs font-semibold text-slate-500">Página {directory.pageInfo.page} de {directory.pageInfo.pages}</span>
          </div>

          {directory.items.length > 0 ? (
            <div className="divide-y divide-slate-200 overflow-hidden rounded-md border border-slate-200 bg-white dark:divide-slate-800 dark:border-slate-800 dark:bg-slate-950">
              {directory.items.map((item) => {
                const displayName = type === 'boards' && item.acronym && item.acronym !== item.name
                  ? `${item.acronym} - ${item.name}`
                  : item.name;
                return (
                  <Link
                    key={item.id}
                    href={{ pathname: '/practice', query: { [config.practiceQueryKey]: item.name } }}
                    prefetch={false}
                    className="flex min-h-20 items-center justify-between gap-5 px-5 py-4 transition-colors hover:bg-indigo-50/60 dark:hover:bg-indigo-950/20"
                  >
                    <span className="min-w-0">
                      <span className="block text-sm font-black text-slate-900 dark:text-slate-100 sm:text-base">{displayName}</span>
                      {item.description ? <span className="mt-1 line-clamp-1 block text-xs text-slate-500 dark:text-slate-400">{item.description}</span> : null}
                    </span>
                    <span className="shrink-0 text-right text-xs font-medium text-slate-500">
                      <strong className="text-sm text-indigo-700 dark:text-indigo-300">{item.questionCount.toLocaleString('pt-BR')}</strong>{' '}
                      {item.questionCount === 1 ? 'questão' : 'questões'}
                    </span>
                  </Link>
                );
              })}
            </div>
          ) : (
            <div className="rounded-md border border-dashed border-slate-300 bg-white px-6 py-16 text-center dark:border-slate-700 dark:bg-slate-950">
              <p className="font-bold text-slate-700 dark:text-slate-200">Nenhum resultado encontrado.</p>
              <p className="mt-2 text-sm text-slate-500">Tente outra letra ou ajuste a busca.</p>
            </div>
          )}

          {directory.pageInfo.pages > 1 ? (
            <nav className="mt-7 flex items-center justify-center gap-3" aria-label="Paginação">
              {directory.pageInfo.hasPrevious ? (
                <Link href={buildDirectoryHref(config.path, { page: directory.pageInfo.page - 1, search, letter })} prefetch={false} className="rounded-md border border-slate-300 bg-white px-5 py-3 text-sm font-bold hover:border-indigo-400 hover:text-indigo-700 dark:border-slate-700 dark:bg-slate-950">Anterior</Link>
              ) : <span className="rounded-md border border-slate-200 px-5 py-3 text-sm font-bold text-slate-300 dark:border-slate-800 dark:text-slate-700">Anterior</span>}
              <span className="px-3 text-sm font-bold text-slate-600 dark:text-slate-300">{directory.pageInfo.page} / {directory.pageInfo.pages}</span>
              {directory.pageInfo.hasMore ? (
                <Link href={buildDirectoryHref(config.path, { page: directory.pageInfo.page + 1, search, letter })} prefetch={false} className="rounded-md border border-slate-300 bg-white px-5 py-3 text-sm font-bold hover:border-indigo-400 hover:text-indigo-700 dark:border-slate-700 dark:bg-slate-950">Próxima</Link>
              ) : <span className="rounded-md border border-slate-200 px-5 py-3 text-sm font-bold text-slate-300 dark:border-slate-800 dark:text-slate-700">Próxima</span>}
            </nav>
          ) : null}
        </section>
      </main>
      <PublicTaxonomyFooter />
    </div>
  );
}
