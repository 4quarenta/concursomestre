# Arquitetura de auth e middleware compartilhados

## Regra

Infraestrutura transversal de autentica��o, sess�o, cookies, JWT, TOTP e middlewares deve viver em `shared/`, e n�o em `api/`.

## Camadas oficiais

- `shared/auth`: config, sess�o, cookies, JWT, autentica��o por request, TOTP.
- `shared/middleware`: autentica��o HTTP, seguran�a transversal, rate limiting.

## Compatibilidade legada

- `api/utils/*` e `api/middleware/*` permanecem apenas como bridges finos.
