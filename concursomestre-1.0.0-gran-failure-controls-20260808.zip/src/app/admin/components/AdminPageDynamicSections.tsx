'use client';

import dynamic from 'next/dynamic';

const AdminSectionLoading = () => (
  <div className="rounded-sm border border-slate-300 bg-white p-8 text-sm font-medium text-slate-500 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-400">
    Carregando secao...
  </div>
);

export const AdminDatabaseManager = dynamic(() => import('./database/AdminDatabaseManager'), { loading: AdminSectionLoading });
export const AdminFinanceSection = dynamic(() => import('./finance/AdminFinance'), { loading: AdminSectionLoading });
export const AdminMarketingSection = dynamic(() => import('./marketing/AdminMarketingSection'), { loading: AdminSectionLoading });
export const AdminPanelSection = dynamic(() => import('./panel/AdminPanelSection'), { loading: AdminSectionLoading });
export const AdminSettingsSection = dynamic(() => import('./settings/AdminSettings'), { loading: AdminSectionLoading });
export const AdminSupportSection = dynamic(() => import('./support/AdminSupportSection'), { loading: AdminSectionLoading });
