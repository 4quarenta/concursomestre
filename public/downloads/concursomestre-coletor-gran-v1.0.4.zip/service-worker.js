const GRAN_API_ORIGIN = 'https://rota-api.grancursosonline.com.br';
const GRAN_API_PATH = '/v1/elastic/questao';
const GRAN_WEB_ORIGIN = 'https://questoes.grancursosonline.com.br';
const MAX_URL_LENGTH = 8000;
const MAX_RESPONSE_BYTES = 8_000_000;
const REQUEST_TIMEOUT_MS = 45_000;
const SESSION_TOKEN_KEY = 'granSession';
const CAPTURE_STATUS_KEY = 'granCaptureStatus';
const HEADER_RULE_ID = 44001;

const ALLOWED_PAGE_ORIGINS = new Set([
  'https://concursomestre.com',
  'http://localhost:3000',
]);

const base64UrlDecode = (value) => {
  const normalized = value.replace(/-/g, '+').replace(/_/g, '/');
  const padding = '='.repeat((4 - (normalized.length % 4)) % 4);
  return atob(normalized + padding);
};

const readTokenClaims = (token) => {
  const parts = String(token || '').split('.');
  if (parts.length !== 3) throw new Error('A credencial Gran nao possui formato JWT valido.');
  try {
    return JSON.parse(base64UrlDecode(parts[1]));
  } catch {
    throw new Error('Nao foi possivel ler a credencial Gran.');
  }
};

const normalizeToken = (value) => String(value || '')
  .trim()
  .replace(/^Bearer\s+/i, '');

const validateToken = (value) => {
  const token = normalizeToken(value);
  if (!token || token.length > 12000 || /[\r\n]/.test(token)) {
    throw new Error('Informe uma credencial valida da sessao Gran.');
  }
  const claims = readTokenClaims(token);
  const clientId = String(claims.id || '').trim();
  if (!clientId || clientId.length > 200 || /[\r\n]/.test(clientId)) {
    throw new Error('A credencial nao possui o identificador de cliente esperado.');
  }
  const expiresAt = Number(claims.exp || 0);
  if (expiresAt > 0 && expiresAt <= Math.floor(Date.now() / 1000)) {
    throw new Error('A sessao Gran expirou. Informe uma nova credencial.');
  }
  return { token, clientId, expiresAt: expiresAt || null };
};

const validateGranUrl = (value) => {
  const raw = String(value || '').trim();
  if (!raw || raw.length > MAX_URL_LENGTH || /[\r\n]/.test(raw)) {
    throw new Error('A URL da consulta Gran e invalida.');
  }
  let url;
  try {
    url = new URL(raw);
  } catch {
    throw new Error('A URL da consulta Gran e invalida.');
  }
  if (
    url.protocol !== 'https:'
    || url.origin !== GRAN_API_ORIGIN
    || url.pathname !== GRAN_API_PATH
    || url.username
    || url.password
    || url.hash
  ) {
    throw new Error('Use somente a rota oficial de questoes da Gran.');
  }
  for (const key of url.searchParams.keys()) {
    if (['authorization', 'access_token', 'token', 'cookie', 'x-client-id'].includes(key.toLowerCase())) {
      throw new Error('Nao inclua credenciais na URL da consulta.');
    }
  }
  return url.toString();
};

const isAllowedSender = (sender) => {
  try {
    const url = new URL(sender?.url || '');
    return ALLOWED_PAGE_ORIGINS.has(url.origin)
      && url.pathname === '/admin/operation/gran-crawler';
  } catch {
    return false;
  }
};

const installHeaderRule = async () => {
  await chrome.declarativeNetRequest.updateSessionRules({
    removeRuleIds: [HEADER_RULE_ID],
    addRules: [{
      id: HEADER_RULE_ID,
      priority: 1,
      action: {
        type: 'modifyHeaders',
        requestHeaders: [
          { header: 'Origin', operation: 'set', value: GRAN_WEB_ORIGIN },
          { header: 'Referer', operation: 'set', value: `${GRAN_WEB_ORIGIN}/` },
        ],
      },
      condition: {
        urlFilter: `|${GRAN_API_ORIGIN}${GRAN_API_PATH}`,
        resourceTypes: ['xmlhttprequest'],
      },
    }],
  });
};

const readBodyWithLimit = async (response) => {
  if (!response.body) {
    const text = await response.text();
    if (new TextEncoder().encode(text).byteLength > MAX_RESPONSE_BYTES) {
      throw new Error('A resposta da Gran excedeu o limite seguro.');
    }
    return text;
  }
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let total = 0;
  let text = '';
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > MAX_RESPONSE_BYTES) {
      await reader.cancel();
      throw new Error('A resposta da Gran excedeu o limite seguro.');
    }
    text += decoder.decode(value, { stream: true });
  }
  return text + decoder.decode();
};

const getSession = async () => {
  const stored = await chrome.storage.session.get(SESSION_TOKEN_KEY);
  if (!stored[SESSION_TOKEN_KEY]) return null;
  try {
    return validateToken(stored[SESSION_TOKEN_KEY].token);
  } catch {
    await chrome.storage.session.remove(SESSION_TOKEN_KEY);
    return null;
  }
};

const captureSessionFromRequest = async (details) => {
  const observedAt = Date.now();
  if (details.initiator !== GRAN_WEB_ORIGIN || !Array.isArray(details.requestHeaders)) {
    await chrome.storage.session.set({
      [CAPTURE_STATUS_KEY]: {
        state: 'origin_rejected',
        observedAt,
      },
    });
    return;
  }
  const authorization = details.requestHeaders.find(
    (header) => String(header.name || '').toLowerCase() === 'authorization',
  );
  if (!authorization?.value || !/^Bearer\s+/i.test(authorization.value)) {
    await chrome.storage.session.set({
      [CAPTURE_STATUS_KEY]: {
        state: 'authorization_missing',
        observedAt,
      },
    });
    return;
  }
  const session = validateToken(authorization.value);
  const clientHeader = details.requestHeaders.find(
    (header) => String(header.name || '').toLowerCase() === 'x-client-id',
  );
  if (clientHeader?.value && clientHeader.value !== session.clientId) {
    await chrome.storage.session.set({
      [CAPTURE_STATUS_KEY]: {
        state: 'client_mismatch',
        observedAt,
      },
    });
    return;
  }
  await chrome.storage.session.set({
    [SESSION_TOKEN_KEY]: {
      token: session.token,
      expiresAt: session.expiresAt,
    },
    [CAPTURE_STATUS_KEY]: {
      state: 'captured',
      observedAt,
    },
  });
};

const clearSession = async () => {
  await chrome.storage.session.remove([SESSION_TOKEN_KEY, CAPTURE_STATUS_KEY]);
  return { connected: false, expiresAt: null };
};

const getStatus = async () => {
  const session = await getSession();
  const stored = await chrome.storage.session.get(CAPTURE_STATUS_KEY);
  const captureStatus = stored[CAPTURE_STATUS_KEY] || null;
  return {
    connected: Boolean(session),
    expiresAt: session?.expiresAt || null,
    version: chrome.runtime.getManifest().version,
    captureState: captureStatus?.state || 'waiting',
    lastObservedAt: Number(captureStatus?.observedAt || 0) || null,
  };
};

const collect = async (urlValue) => {
  const session = await getSession();
  if (!session) throw new Error('Abra a extensao e conecte uma sessao Gran valida.');
  const requestUrl = validateGranUrl(urlValue);
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const response = await fetch(requestUrl, {
      method: 'GET',
      cache: 'no-store',
      credentials: 'omit',
      redirect: 'error',
      referrer: `${GRAN_WEB_ORIGIN}/`,
      referrerPolicy: 'strict-origin-when-cross-origin',
      headers: {
        accept: 'application/json, text/plain, */*',
        'accept-language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
        authorization: `Bearer ${session.token}`,
        'x-client-id': session.clientId,
      },
      signal: controller.signal,
    });
    const body = await readBodyWithLimit(response);
    if (response.status === 401 || response.status === 403) {
      await clearSession();
      throw new Error('A Gran recusou a sessao. Conecte uma nova credencial na extensao.');
    }
    if (response.status === 429) {
      throw new Error('A Gran limitou temporariamente as consultas. Aguarde e tente novamente.');
    }
    if (!response.ok) throw new Error(`A Gran respondeu com HTTP ${response.status}.`);
    let json;
    try {
      json = JSON.parse(body);
    } catch {
      throw new Error('A Gran respondeu com JSON invalido.');
    }
    return {
      status: response.status,
      requestUrl,
      json,
    };
  } catch (error) {
    if (error?.name === 'AbortError') {
      throw new Error('A consulta Gran excedeu o tempo limite.');
    }
    throw error;
  } finally {
    clearTimeout(timeout);
  }
};

chrome.runtime.onInstalled.addListener(() => {
  void installHeaderRule();
});
chrome.runtime.onStartup.addListener(() => {
  void installHeaderRule();
});
void installHeaderRule();

chrome.webRequest.onBeforeSendHeaders.addListener(
  (details) => {
    void captureSessionFromRequest(details).catch(async () => {
      await chrome.storage.session.set({
        [CAPTURE_STATUS_KEY]: {
          state: 'invalid_credential',
          observedAt: Date.now(),
        },
      });
    });
  },
  {
    // A sessao pode aparecer primeiro em rotas de perfil, filtros ou prova.
    // A coleta continua limitada por validateGranUrl() a /v1/elastic/questao.
    urls: [`${GRAN_API_ORIGIN}/*`],
    types: ['xmlhttprequest'],
  },
  ['requestHeaders', 'extraHeaders'],
);

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const action = String(message?.action || '');
  const popupAction = ['CLEAR_SESSION', 'GET_STATUS'].includes(action)
    && sender?.id === chrome.runtime.id
    && !sender?.tab;
  const pageAction = ['PING', 'COLLECT'].includes(action) && isAllowedSender(sender);
  if (!popupAction && !pageAction) {
    sendResponse({ success: false, message: 'Origem da solicitacao nao autorizada.' });
    return false;
  }
  const operation = action === 'CLEAR_SESSION'
      ? clearSession()
      : action === 'COLLECT'
        ? collect(message.url)
        : getStatus();
  operation
    .then((data) => sendResponse({ success: true, data }))
    .catch((error) => sendResponse({
      success: false,
      message: error instanceof Error ? error.message : 'Falha no coletor Gran.',
    }));
  return true;
});
