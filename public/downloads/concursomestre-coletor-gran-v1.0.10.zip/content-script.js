const PAGE_SOURCE = 'concursomestre-gran-page';
const EXTENSION_SOURCE = 'concursomestre-gran-extension';
const ALLOWED_TYPES = new Set(['PING', 'COLLECT', 'COLLECT_TAXONOMY_PAGE']);
const CRAWLER_PATH = '/admin/operation/gran-crawler';

const isAllowedCrawlerPage = () => (
  (window.location.origin === 'https://concursomestre.com'
    || window.location.origin === 'http://localhost:3000')
  && (window.location.pathname === CRAWLER_PATH
    || window.location.pathname.startsWith(`${CRAWLER_PATH}/`))
);

window.addEventListener('message', (event) => {
  if (
    !isAllowedCrawlerPage()
    || event.source !== window
    || event.origin !== window.location.origin
    || event.data?.source !== PAGE_SOURCE
    || !ALLOWED_TYPES.has(event.data?.type)
    || typeof event.data?.requestId !== 'string'
  ) {
    return;
  }
  const requestId = event.data.requestId;
  const action = event.data.type;
  chrome.runtime.sendMessage({
    action,
    url: action === 'COLLECT' ? String(event.data.url || '') : undefined,
    kind: action === 'COLLECT_TAXONOMY_PAGE' ? String(event.data.kind || '') : undefined,
    page: action === 'COLLECT_TAXONOMY_PAGE' ? Number(event.data.page || 1) : undefined,
    rootExternalIds: action === 'COLLECT_TAXONOMY_PAGE' ? event.data.rootExternalIds : undefined,
  }, (response) => {
    const runtimeError = chrome.runtime.lastError;
    window.postMessage({
      source: EXTENSION_SOURCE,
      requestId,
      type: `${action}_RESULT`,
      success: !runtimeError && response?.success === true,
      data: response?.data,
      message: runtimeError?.message || response?.message || null,
    }, window.location.origin);
  });
});

if (isAllowedCrawlerPage()) {
  window.postMessage({
    source: EXTENSION_SOURCE,
    type: 'EXTENSION_READY',
    version: chrome.runtime.getManifest().version,
  }, window.location.origin);
}
